![professor](professor.jpg)<br>
# John Doe

**Game Developer at Blizzard**
I have created and managed multiple games at Blizzard such as Overwatch and World of Warcraft

<hr>

## Experience
* I have expeirence creating maps for multiple high profile games.
  
<hr>

## Education
### Harvard University
***Bachelor of Computer Science: Sept, 2020 - Jun,2024***

### Manchester Regional High School
***High School Diploma: 2020***

<hr>

## Projects
### Overwatch
***Helped create multiple maps***

### World Of Warcraft
***Helped create multiple expansions***

### Skills
***Map Development***
* I have several years of map development in major games.

***Exceptional Leadership***
* I was a project manager for Overwatch for 4 years.

***Extremely Creative***
* I came up with multiple ideas for both Overwatch and World of Warcraft.

<hr>

## Recognition
***Game of the Year:*** Overwatch 2016

<hr>

## Associations
***Blizzard Entertainment***

### Additional Links
* [Overwatch](https://overwatch.blizzard.com/en-us/)
* [World of Warcraft](https://worldofwarcraft.blizzard.com/en-us/)
